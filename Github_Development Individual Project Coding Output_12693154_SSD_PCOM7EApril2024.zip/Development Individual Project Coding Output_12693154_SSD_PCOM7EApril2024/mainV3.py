import sqlite3
import hashlib #(Bonisteel, 2024)
import shutil
import os #(Doorwar, 2024)
from datetime import datetime
from getpass import getpass
from cryptography.fernet import Fernet #(Magazine, 2023)

#Global Variables for the program
DATABASE = "musicDB.db"
DB_DIR = "Artifacts"
KEY = "key.key"

#This method generates a key from Fernet for Encryption
def generate_key(): #(Magazine, 2023)
    """Used to generate a key file"""
    key = Fernet.generate_key()
    with open(KEY, "wb") as file:
        file.write(key)

#This method loads the generated key from Fernet for Encryption
def load_key(): #(Magazine, 2023)
    """Used to load a key file"""
    return open(KEY, "rb").read()

#This method is used for creating a user for the database
def create_user(username, password, role="user"): #(Bonisteel, 2024)
    """Used to create a user"""
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    hashed_password = hashlib.sha256(password.encode()).hexdigest()
    cursor.execute("INSERT INTO users VALUES (?, ?, ?)", (username, hashed_password, role))
    conn.commit()
    conn.close()   

#This method is used for authenticating a user for the database
def auth_user(username, password): #(Bonisteel, 2024)
    """Used to authenticate a user"""
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("SELECT password, role FROM users WHERE username=?", (username,))
    user_data = cursor.fetchone()
    conn.close()
    if user_data:
        hashed_password, role = user_data
        if hashlib.sha256(password.encode()).hexdigest() == hashed_password:
            return True, role
    return False, None

#This method is used to add artifacts to the database.
def create_artifact(artifact_name, lyric, score, artist_name, record=None):#(Bonisteel, 2024)
    """Creation of an Artifact"""
    path = os.path.join(DB_DIR, artifact_name)
    if not os.path.exists(KEY):
        generate_key()
    key = load_key()
    f = Fernet(key)
    encrypted_lyric = f.encrypt(lyric.encode())
    encrypted_score = f.encrypt(score.encode())

    checksum = hashlib.sha256(lyric.encode()).hexdigest()

    with open(path, "wb") as file:
        file.write(encrypted_lyric)
        file.write(encrypted_score)

    record_directory = None
    if record:
        record_directory = os.path.join(DB_DIR, "record", artifact_name + ".mp3")
        shutil.move(record, record_directory)

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("INSERT INTO artifacts (artifact_name, score, lyric, record, artist_name, timestamp, checksum) VALUES (?, ?, ?, ?, ?, ?, ?)",(artifact_name, encrypted_lyric, encrypted_score, record_directory, artist_name, timestamp, checksum))
    conn.commit()
    conn.close()
    print("Artifact created successfully.")
    print(f"Timestamp: {timestamp}\n\n")

#This method is used to retrieve artifacts from the database.
def retrieve(artifact_name):
    """Fetches an artifact from the database by name"""
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("SELECT score, lyric, record FROM artifacts WHERE artifact_name=?", (artifact_name,))
    artifact_data = cursor.fetchone()
    conn.close()

    if artifact_data:
        encrypted_lyric, encrypted_score, record = artifact_data
        key = load_key()
        f = Fernet(key)
        decrypted_contentlyric = f.decrypt(encrypted_lyric).decode()
        decrypted_contentscore = f.decrypt(encrypted_score).decode()
        print("Artifact Lyric:")
        print(decrypted_contentlyric)
        print("\nArtifact Score:")
        print(decrypted_contentscore)

        if record and os.path.exists(record):
            print("Record File:")
            print(record)
        else:
            print("Record file not found for this Artifact.")
    else:
        print("Artifact not found.")

#This method is for the admin user only. This allows admins to view all artifacts on the database.
def view_all():
    """Allows all artifacts to be viewed by Administrators"""
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("SELECT artifact_name FROM artifacts")
    artifacts = cursor.fetchall()
    conn.close()

    print("\n\nExisting Artifacts:")
    for artifact in artifacts:
        print("-", artifact[0])

def view_all_user(username):
    """Allows all artifacts to be viewed by Administrators"""
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM artifacts WHERE artist_name=?", (username,))
    artifacts = cursor.fetchall()
    conn.close()

    print("\n\nExisting Artifacts:")
    for artifact in artifacts:
        print("-", artifact[0])

#This method will delete the selected artifact.
def delete_artifact(artifact_name, username):
    """Deletes an Artifact from the database"""
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("SELECT artist_name, record FROM artifacts WHERE artifact_name=?", (artifact_name,))
    artifact_data = cursor.fetchone()
    if not artifact_data:
        print("Artifact not found.")
        conn.close()
        return

    artist_name, record = artifact_data
    if artist_name == username or username == "admin":
        path = os.path.join(DB_DIR, artifact_name)
        if os.path.exists(path):
            os.remove(path)      
        if record and os.path.exists(record):
            os.remove(record)
        cursor.execute("DELETE FROM artifacts WHERE artifact_name=?", (artifact_name,))
        conn.commit()
        print(f"Artifact '{artifact_name}' deleted successfully.")
    else:
        print("You do not have permission to delete this Artifact.")
    conn.close()

#This method is for the admin user only. This will promote a normal user to an administrative user.
def promote_user(username):
    """Method to promote a user"""
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET role=? WHERE username=?", ("admin", username))
    conn.commit()
    conn.close()
    print(f"User '{username}' promoted to admin successfully.")

#This method is for the admin user only. This will demote an administrative user to a normal user.
def demote_user(username):
    """Method to demote a user"""
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET role=? WHERE username=?", ("user", username))
    conn.commit()
    conn.close()
    print(f"User '{username}' Demonted to user successfully.")

#This method will verify artifacts with the required CheckSum function.
def artifact_verification(artifact_name):
    """Artifact Verification"""
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("SELECT lyirc FROM artifacts WHERE artifact_name = ?", (artifact_name,))
    artifact_data = cursor.fetchone()
    conn.close()

    if artifact_data:
        content = artifact_data[0]
        checksum = hashlib.sha256(content.encode()).hexdigest()
        return checksum
    else:
        return None

#This method works the main menu of the program.
def main_menu():
    """This is the main menu of the program"""
    while True:
        print("\nWelcome to the Music Copyright Protection Database!")
        print("1. Login")
        print("2. Register")
        print("0. Exit")
        choice = input("Enter your choice: ")

        if choice == "1":
            print("\nLogin")
            username = input("Enter username: ")
            password = getpass("Enter password: ")
            authenticated, role = auth_user(username, password)
            if not authenticated:
                print("Authentication failed.")
            else:
                print(f"\n\nWelcome, {username} ({role})")
                sub_menu(username, role)

        elif choice == "2":
            print("\nOnly new users can register. Administrative users can only be registered by current Administrative users.")
            print("\nUser Registration")
            username = input("Enter new username: ")
            password = getpass("Enter password: ")
            create_user(username, password, "user")
            print("User registered successfully!\n\n")

        elif choice == "0":
            print("Exiting program.")
            break
        else:
            print("Invalid choice.")

#This method works the sub menu of the program.
def sub_menu(username, role):
    """Method initilizes menu after login"""
    while True:
        print("\nMain Menu:")
        print("1. Create Artifact")
        print("2. Retrieve Artifact")
        print("3. View all Artifacts")
        print("4. Delete Artifact")
        print("5. Verify Checksum")
        if role == "admin":
            print("6. Promote User")
            print("7. Demote User")
        print("0. Logout")
        choice = input("Enter your choice: ")

        if choice == "1":
            artifact_name = input("\n\nEnter Artifact name: ")

            lyric_option = input("Do you want to add a lyric to the artifact? (y/n): ").lower()
            if lyric_option == "y":
                lyric = input("Enter Artifact lyric content: ")
            else:
                lyric = "No Lyric"

            score_option = input("Do you want to add a score to the artifact? (y/n): ").lower()
            if score_option == "y":
                score = input("Enter Artifact score content: ")
            else:
                score = "No Score"

            record_option = input("Do you want to add a record to the artifact? (y/n): ").lower()
            if record_option == "y":
                record = input("Enter path to the music file: ")
            else:
                record = None
                artist_name = username
                create_artifact(artifact_name, lyric, score, artist_name, record)

        elif choice == "2":
            artifact_name = input("\n\nEnter Artifact name: ")
            retrieve(artifact_name)

        elif choice == "3":
            if role == "admin":
                view_all()
            else:
                view_all_user(username)

        elif choice == "4":
            artifact_name = input("\n\nEnter Artifact name to delete: ")
            delete_artifact(artifact_name, username)

        elif choice == "5":
            artifact_name = input("\n\nEnter Artifact name to verify checksum: ")
            checksum = artifact_verification(artifact_name)
            if checksum:
                print(f"Checksum for Artifact '{artifact_name}': {checksum}")
            else:
                print("Artifact not found.")

        elif choice == "6" and role == "admin":
            username = input("\n\nEnter the username to promote: ")
            promote_user(username)

        elif choice == "7" and role == "admin":
            username = input("\n\nEnter the username to demote: ")
            demote_user(username)

        elif choice == "0":
            print("\n\nLogging out.")
            break

        else:
            print("\n\nInvalid choice.")

#This method initializes the program.
def initialize(): #(Peterson, 2024)
    """Initializing the python program for the first time."""
    #Directory creation for the program if one does not exist already
    if not os.path.exists(DB_DIR):
        os.makedirs(DB_DIR)
        os.makedirs(os.path.join(DB_DIR, "record"))

    #Database Creation for the Program if one does not exist already
    if not os.path.exists(DATABASE):
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        cursor.execute('''CREATE TABLE IF NOT EXISTS users
                 (username TEXT PRIMARY KEY, 
                   password TEXT, 
                   role TEXT)''')

        cursor.execute('''CREATE TABLE IF NOT EXISTS artifacts
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, 
                   artifact_name TEXT, 
                   score TEXT,
                   lyric TEXT, 
                   record TEXT, 
                   artist_name TEXT, 
                   timestamp TEXT, 
                   checksum TEXT)''')
        conn.commit()
        conn.close()

    #The code below initializes the administrator for the program.
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE username=?", ("admin",))
    admin_exists = cursor.fetchone()
    conn.close()
    if not admin_exists:
        print("The program needs to initialize for the first time.")
        print("\nDatabase created.")
        print("Directory for Artifacts created.")
        print("\n\nAn administrator for the program is needed.")
        print("\nPlease create a password for the user: 'admin'")
        admin_password = getpass("\n\nEnter admin password: ")
        create_user("admin", admin_password, "admin")
        print("\n\nAdmin user created successfully")

#The code below initializes the program.
if __name__ == "__main__":
    initialize()
    main_menu()
